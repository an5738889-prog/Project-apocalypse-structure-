@echo off
set VERSION=8.1.1
set BASE=%USERPROFILE%\.gradle\wrapper\dists\manual-gradle-%VERSION%
set GRADLE=%BASE%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -Command "Invoke-WebRequest https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip -OutFile '%BASE%\gradle.zip'"
  powershell -Command "Expand-Archive -Force '%BASE%\gradle.zip' '%BASE%'"
  del "%BASE%\gradle.zip"
)
call "%GRADLE%" %*
