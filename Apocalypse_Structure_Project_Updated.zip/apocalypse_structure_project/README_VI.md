# Apocalypse Structure — Forge 1.20.1

Project mã nguồn mod sinh công trình tự nhiên cho Minecraft Java 1.20.1 + Forge 47.4.23.

## Đã chỉnh trong bản này
- Đã tạo cấu hình worldgen cho **15 công trình độc lập** có định dạng Minecraft Structure NBT.
- Các công trình dùng chung một lịch sinh: `spacing: 32`, `separation: 8` (mức vừa phải; không có nghĩa cứ đúng 32 chunk chắc chắn có công trình).
- Biome dùng tag `#minecraft:is_overworld`, áp dụng cho phần lớn biome Overworld.
- Nhà dân được ưu tiên; cửa hầm bunker ít gặp hơn.
- 6 file `bunker_tunnel_1.nbt` đến `bunker_tunnel_6.nbt` được giữ lại nhưng **chưa tự sinh độc lập** vì có thể chỉ là các đoạn hầm rời.
- `survival1.schem` là Sponge Schematic v2, **không phải** Minecraft Structure NBT. Tao đổi đuôi file để tránh game đọc nhầm; file này chưa được đưa vào worldgen.

## Thư mục quan trọng
`src/main/resources/data/apocalypse_structure/`
- `structures/` — các file công trình NBT; `survival1.schem` là schematic riêng.
- `worldgen/structure/` — cấu hình từng công trình tự sinh.
- `worldgen/template_pool/<tên>/start.json` — liên kết cấu hình với NBT.
- `worldgen/structure_set/overworld_structures.json` — chọn công trình và điều khiển tần suất sinh.

## Thêm công trình NBT mới
1. Xuất công trình từ Structure Block hoặc công cụ tương thích Minecraft 1.20.1 thành file `.nbt`.
2. Đặt file vào `structures/`, ví dụ `checkpoint.nbt`. Dùng tên chữ thường, số và dấu gạch dưới; không dùng dấu cách.
3. Sao chép bộ cấu hình của một công trình hiện có: file `worldgen/structure/<tên>.json`, thư mục `worldgen/template_pool/<tên>/start.json`.
4. Đổi ID trong hai file JSON thành `apocalypse_structure:checkpoint` (pool dùng `apocalypse_structure:checkpoint/start`).
5. Thêm vào `worldgen/structure_set/overworld_structures.json` entry `{"structure":"apocalypse_structure:checkpoint","weight":4}`.
6. Nếu file là `.schem` từ WorldEdit/Sponge, **đừng chỉ đổi đuôi thành `.nbt`**; phải chuyển đổi/xuất lại thành Minecraft Structure NBT trước.

## Build trên iPad bằng GitHub Codespaces
1. Tạo repository GitHub mới, ví dụ `apocalypse-structure`.
2. Giải nén ZIP và upload **nội dung bên trong** thư mục `apocalypse_structure_project` lên repo (không để lồng thêm một thư mục cấp thừa).
3. Mở repository bằng **Code → Codespaces → Create codespace**.
4. Mở Terminal và chạy:

   ```bash
   java -version
   ./gradlew --version
   ./gradlew build
   ```

   Cần Java 17 và Internet để tải Gradle/ForgeGradle ở lần chạy đầu.
5. Nếu build thành công, JAR sẽ ở `build/libs/apocalypse-structure-1.0.0.jar`.
6. Chép JAR vào thư mục `mods` của profile Forge 1.20.1 trong ZalithLauncher.

## Kiểm tra trong game
- Dùng **world mới** để thử; công trình không tự xuất hiện trong chunk đã tạo từ trước.
- Đi khám phá nhiều chunk. Muốn công trình thường xuyên hơn thì giảm `spacing`; muốn thưa hơn thì tăng `spacing`. `spacing` phải lớn hơn `separation`.
- Nhà hoặc cửa hầm có thể chưa hợp địa hình (ví dụ nền dốc hoặc phần hầm lộ thiên). Cần kiểm tra trong game.

## Trạng thái kiểm tra
- Đã xác nhận 21 file `.nbt` đều giải nén gzip và có các tag cơ bản của Minecraft structure template.
- Phát hiện `survival1.nbt` thực ra là Sponge Schematic v2 nên đã đổi tên thành `survival1.schem` và không đưa vào worldgen.
- Đã kiểm tra cú pháp JSON của cấu hình worldgen.
- Chưa build bằng ForgeGradle và chưa thử sinh công trình trực tiếp trong Minecraft; cần test thực tế trước khi xem là hoàn thiện.
