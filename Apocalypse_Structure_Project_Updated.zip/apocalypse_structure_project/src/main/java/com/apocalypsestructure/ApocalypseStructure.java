package com.apocalypsestructure;

import net.minecraftforge.fml.common.Mod;

/** Main Forge entry point. World-generation data is supplied by JSON resources. */
@Mod(ApocalypseStructure.MOD_ID)
public final class ApocalypseStructure {
    public static final String MOD_ID = "apocalypse_structure";

    public ApocalypseStructure() {
        // Structure generation is defined in data/apocalypse_structure/worldgen.
    }
}
